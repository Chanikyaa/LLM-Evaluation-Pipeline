# LLM Evaluation and Testing Pipeline

A small, reproducible evaluation lab for retrieval-augmented generation (RAG) systems. It compares retrieval configurations, computes transparent retrieval and answer diagnostics, emits JSON reports, and runs a CI regression gate. The included demo is deterministic and needs no API key.

> **Scope warning:** this is an evaluation-pipeline MVP and teaching fixture, not proof of real-world LLM quality. The mock answer adapter uses the reference answer when a labeled relevant document is retrieved. Lexical answer metrics are heuristics; use a larger human-reviewed dataset and real model adapter before making quality claims.

## Features

- Versioned JSONL examples with disjoint development and held-out test splits.
- Transparent BM25-inspired lexical retrieval with optional title boost.
- Recall@k, reciprocal rank/MRR summary, nDCG@k, normalized exact match, token F1, evidence-overlap proxy, and citation precision.
- Local latency measurements and approximate token/cost fields.
- Named configuration comparison and machine-readable reports.
- Dataset validation, deterministic regression tests, and GitHub Actions CI quality gate.

Non-goals for this MVP: production-scale benchmark management, provider-specific token accounting, semantic entailment verification, real LLM judging, distributed experiment tracking, or a hosted dashboard.

## Architecture

```mermaid
flowchart LR
    A[JSONL dataset] --> B[Dataset validator]
    C[Document corpus] --> D[Retriever]
    B --> E[Evaluation runner]
    D --> E
    E --> F[Answer adapter]
    F --> G[Metrics]
    G --> H[JSON comparison report]
    H --> I[CI regression gate]
```

## Requirements and setup

- Python 3.10+
- `pytest` for development tests
- No API key and no runtime dependencies for the core local demo

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install -e ".[dev]"
pytest -q
```

## Run the demo

From the repository root:

```bash
# One configuration on development data
python -m eval_pipeline.cli run --split dev --config lexical --k 3 --output reports/dev-lexical.json

# Compare two configurations on the same held-out split
python -m eval_pipeline.cli compare --split test --k 3 --output reports/test-comparison.json

# Run the same gate used in CI
python scripts/check_regression.py
```

The CLI prints the report and writes JSON to the requested path. `lexical` uses no title boost; `title-boost` adds a lexical title boost. The comparison is measured on the bundled synthetic examples, not a representative external benchmark.

## Dataset format and versioning

Each JSONL row contains `id`, `split` (`dev` or `test`), `question`, `reference_answer`, and `relevant_doc_ids`. Corpus documents in `data/corpus.json` contain unique `id`, `title`, and `text` fields. The fixture is version `1.0.0`; update this version in the runner and changelog when labels or data meaningfully change. Keep test examples held out from tuning.

## Metrics and interpretation

| Metric | Interpretation | Caveat |
|---|---|---|
| Recall@k | Fraction of labeled relevant documents retrieved | Depends on completeness of relevance labels |
| MRR | Rewards first relevant result near the top | Per-query reciprocal rank is also available |
| nDCG@k | Rewards relevant documents at higher ranks | Binary relevance labels only in this fixture |
| Exact match | Strict normalized answer match | Penalizes valid paraphrases |
| Token F1 | Word-level overlap with reference | Not semantic correctness |
| Evidence overlap | Answer token overlap with retrieved evidence | Not entailment or factual verification |
| Citation precision | Cited IDs that are labeled relevant | Relevant does not always mean directly supportive |
| Latency | Local retrieval duration | Noisy, machine-dependent measurement |
| Token/cost fields | Whitespace word-count proxy and configured estimate | Not provider-reported usage; default cost is zero |

See [evaluation methodology](docs/evaluation-methodology.md) for limitations and recommendations.

## CI and quality gates

GitHub Actions installs the package, runs tests, runs a held-out Recall@3 gate, and generates a comparison report. The threshold in `scripts/check_regression.py` is only a fixture smoke test. Establish meaningful thresholds from a larger labeled benchmark before using it to block production releases.

## Security and privacy

The bundled demo makes no network calls and uses synthetic public-style text. Do not place confidential, regulated, or employer data into evaluation fixtures without authorization. Real-provider adapters must keep keys in environment variables or a secret manager, apply timeouts and rate limits, avoid logging raw sensitive prompts, and record model/version metadata.

## Limitations and next steps

- Small synthetic dataset: not statistically representative.
- The mock answer adapter is a retrieval-dependent fixture, not a generative model.
- No semantic entailment model or LLM-as-a-judge is bundled.
- Token counts and costs are estimates until provider usage is integrated.
- Local latency is not a deployment benchmark.
- Add a real provider adapter, human-reviewed evaluation set, per-category error analysis, judge calibration, and experiment-store integration as follow-up work.

## Reproducibility

The core code uses the Python standard library. Pin dependency versions in a lock file before formal release. Run `pytest -q` and `python scripts/check_regression.py` after any changes. Never claim quality improvements without running the same versioned dataset against both configurations and reporting measured results.

"""Simple CI quality gate for held-out retrieval; uses no external model."""
from pathlib import Path
from eval_pipeline.dataset import load_corpus, load_dataset
from eval_pipeline.runner import evaluate

ROOT = Path(__file__).resolve().parents[1]
# Set from a documented product requirement once a representative dataset exists.
MIN_RECALL_AT_K = 0.50

def main() -> int:
    data = load_dataset(ROOT / "data/examples.jsonl", "test")
    corpus = load_corpus(ROOT / "data/corpus.json")
    report = evaluate(data, corpus, config_name="lexical", title_boost=0, k=3)
    recall = report["metrics"]["recall_at_k"]
    print(f"held-out Recall@3={recall:.3f}; required>={MIN_RECALL_AT_K:.3f}")
    if recall < MIN_RECALL_AT_K:
        print("FAIL: retrieval quality gate not met")
        return 1
    print("PASS: retrieval quality gate met (fixture dataset only)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env sh
set -eu
python -m eval_pipeline.cli run --split dev --config lexical --k 3 --output reports/dev-lexical.json
python -m eval_pipeline.cli compare --split test --k 3 --output reports/test-comparison.json
python scripts/check_regression.py

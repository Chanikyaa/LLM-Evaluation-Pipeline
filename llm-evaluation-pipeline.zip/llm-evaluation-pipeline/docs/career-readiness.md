# Career readiness: LLM Evaluation and Testing Pipeline

## Target roles and skills

**Roles:** Generative AI Engineer, Applied AI Engineer, ML Engineer, NLP Engineer, AI Quality/Evaluation Engineer.

**Demonstrated skills:** benchmark design, train/dev/test hygiene, retrieval metrics, evaluation harnesses, regression testing, data validation, experiment comparison, CI gates, metric interpretation, Python packaging, reproducibility, and honest reporting of limitations.

## Requirement-to-implementation mapping

| Requirement | Implementation | Status |
|---|---|---|
| Versioned questions and reference answers | `data/examples.jsonl`, dataset version in report | Implemented fixture |
| Development/test separation | `split` validation and CLI split selection | Implemented |
| Retrieval metrics | Recall@k, reciprocal rank, nDCG@k | Implemented |
| Answer/citation checks | Exact match, token F1, evidence overlap, citation precision | Implemented heuristics |
| Latency/tokens/cost | Local latency and approximate usage fields | Implemented with caveats |
| Compare two configs | `compare` command | Implemented |
| CI regression gate | GitHub Actions + Recall@3 script | Implemented; CI not remotely run here |
| Real LLM judge | Not bundled | Future work |

## Resume bullet templates (fill only with verified results)

- Built a reproducible LLM/RAG evaluation harness with **[N]** labeled cases and retrieval metrics including Recall@k, MRR, and nDCG.
- Added CI regression gates that detect retrieval-quality changes across **[N]** configurations on a held-out evaluation split.
- Implemented evidence and citation diagnostics, reducing manually reviewed unsupported citations from **[baseline]** to **[measured result]** on **[dataset]**.

Do not use the bracketed values until measured on a representative dataset.

## Measurements to collect next

Dataset size and label provenance; inter-annotator agreement; per-domain Recall@k/MRR/nDCG; answer correctness and groundedness from human review; citation support precision; confidence intervals; provider-reported token usage/cost; p50/p95 latency; run-to-run variance; CI false-positive rate.

## Five-minute demo script

1. Explain why a change to a RAG system needs a fixed benchmark (30 seconds).
2. Show the labeled dataset and separate dev/test splits (45 seconds).
3. Run a single lexical configuration on dev (45 seconds).
4. Compare lexical vs title-boost configurations on the same test split (60 seconds).
5. Open a per-example report and inspect a missed relevant document and its metrics (60 seconds).
6. Run the CI quality gate and explain why the threshold is a fixture smoke test only (45 seconds).
7. Explain how a real answer provider and human-reviewed labels would replace the mock adapter (45 seconds).

## Two-minute architecture explanation

The dataset loader validates schema, IDs, and split names. A transparent retriever ranks the corpus under a named configuration. The evaluation runner computes per-example retrieval metrics, uses a deterministic mock answer adapter to exercise answer and citation metrics, then aggregates metrics into JSON. The CLI compares two configurations on the same split, and CI runs tests plus a small held-out retrieval gate. The mock answer is deliberately not represented as a real LLM benchmark; a production extension should plug in a provider adapter and human-reviewed dataset while keeping the same evaluation contract.

## Interview questions and model answers

1. **Why separate dev and test?** Use dev for iteration and reserve test for final estimates to reduce overfitting to benchmark feedback.
2. **What does Recall@k measure?** The fraction of known relevant items in the top k; it depends on complete relevance labels.
3. **What does MRR emphasize?** The rank of the first relevant result; higher scores reward earlier relevant hits.
4. **How is nDCG different from Recall@k?** nDCG discounts lower-ranked relevant results, while recall measures coverage.
5. **Why not use exact match alone?** It rejects valid paraphrases and doesn't verify factual support.
6. **What does token F1 miss?** Semantics, negation, factual consistency, and valid wording differences.
7. **Does lexical evidence overlap prove groundedness?** No. It is only a token-overlap diagnostic; entailment or human review is needed.
8. **How should citations be evaluated?** Label whether each cited source supports the associated claim, then compute precision/recall and inspect errors.
9. **Why can a test set become contaminated?** Repeated tuning based on its results makes it part of the development feedback loop.
10. **What makes an evaluation reproducible?** Versioned data, fixed splits, configuration/model versions, deterministic seeds where applicable, and recorded dependencies.
11. **How would you add a hosted LLM?** Define an adapter returning answer, citations, provider usage, model ID, and timing; add timeouts, retries, and secret handling.
12. **How do you measure cost?** Prefer provider-reported input/output token counts multiplied by a dated pricing snapshot; don't use word counts as billing truth.
13. **What should CI block?** Critical, predeclared regressions on a stable, representative benchmark—not tiny-fixture noise.
14. **Why compare configs on the same examples?** Paired comparison reduces confounding from dataset composition.
15. **How would you calibrate an LLM judge?** Compare it with blinded human annotations, measure agreement and bias, and track judge model/prompt versions.
16. **How would you analyze failures?** Group by retrieval miss, unsupported answer, bad citation, ambiguity, domain, and query type; review examples rather than only aggregates.
17. **What is the risk of tuning on held-out test data?** Reported test metrics become optimistic and no longer estimate unseen performance cleanly.
18. **How would you report uncertainty?** Use paired bootstrap or suitable confidence intervals on a sufficiently large, representative test set.

## Debugging/system-design scenarios

- Recall suddenly drops after a corpus update: compare corpus IDs, chunking, tokenization, ranking and relevance-label coverage.
- Exact match falls while human quality seems stable: inspect paraphrases and add semantic/human-rated metrics.
- Judge scores rise but users complain: audit judge bias, prompt leakage, and disagreement with human labels.
- CI fails intermittently on latency: separate quality gates from noisy performance tests; benchmark in controlled hardware.
- A config wins only on test: treat as possible test-set overfit; freeze the current report and validate on a new untouched set.

## Likely interviewer objections and honest responses

- **“This doesn't test a real LLM.”** Correct: the first version tests the evaluation harness and retrieval configurations with a deterministic adapter; real-provider evaluation is the next milestone.
- **“The dataset is tiny.”** Correct: it validates plumbing only and supports no broad quality claims.
- **“Groundedness is only overlap.”** Correct: the metric is labeled as a proxy; use claim-level support annotations or calibrated judging for stronger evidence.
- **“The threshold is arbitrary.”** Correct: it is a smoke-test threshold, not a product SLO; derive real gates from representative labeled data.

## GitHub publication commands

```bash
git init
git add .
git status
git commit -m "Build LLM evaluation and regression pipeline"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

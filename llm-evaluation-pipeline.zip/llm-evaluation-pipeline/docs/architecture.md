# Architecture and data flow

```mermaid
flowchart TD
    A[Versioned JSONL questions] --> B[Dataset validation]
    C[Document corpus] --> D[Lexical retriever]
    B --> E[Evaluation runner]
    D --> E
    E --> F[Mock answer adapter]
    F --> G[Retrieval and answer metrics]
    G --> H[JSON report]
    H --> I[Comparison and CI quality gate]
```

The evaluation runner is intentionally provider-agnostic at the boundary: a future answer adapter can call a local model or provider API while returning answer text, citations, usage, and timing metadata. The included adapter is deterministic and local. The CLI does not make network requests.

# Engineering log

## 2026-10-25 — Initial MVP

- Created a standard-library evaluation core with a small optional pytest development dependency.
- Chose a transparent BM25-inspired lexical retriever so the ranking logic can be inspected without introducing a vector database dependency.
- Added lexical and title-boost configurations, versioned synthetic data, retrieval/answer/citation diagnostics, JSON reports, and a held-out CI smoke gate.
- Added explicit warnings that mock answers, lexical overlap, approximate tokens, and tiny-data thresholds are not production quality evidence.
- Verification in this environment: `pytest -q` → 9 passed; `python scripts/check_regression.py` → passed with Recall@3 1.000 on three synthetic held-out examples; `python -m compileall -q src tests scripts` → passed.
- Comparison on held-out fixture: both configurations scored Recall@3=1.0, MRR=1.0, nDCG@3=1.0, exact match=1.0, token F1=1.0, evidence overlap=1.0, citation precision=0.5. This is a ceiling effect on a tiny fixture, not evidence that title boosting helps. Latency differences are too small/noisy to interpret.
- Not verified: remote GitHub Actions execution, real provider adapter, model-based judge, large-scale benchmark, statistical confidence intervals, hosted deployment.

## Next steps

1. Build a larger independently labeled dataset with harder distractors and reviewed citation-support labels.
2. Add provider adapter(s) that record actual model IDs, provider-reported token usage, latency, and errors.
3. Add human-reviewed correctness/groundedness and judge calibration.
4. Add paired bootstrap confidence intervals and per-category error analysis.
5. Derive CI thresholds from predeclared product requirements and a representative benchmark.

# Evaluation methodology

## Dataset protocol

`data/examples.jsonl` is a tiny synthetic, versioned teaching fixture (`dataset_version=1.0.0` in reports). Each row has a stable ID, a `dev` or `test` split, a question, reference answer, and labeled relevant document IDs. Development examples are for iteration. Run the held-out test split for final comparisons; do not tune configurations repeatedly against it. The sample is intentionally too small to support general claims about real systems.

## Retrieval metrics

- **Recall@k**: fraction of labeled relevant documents retrieved in the first k results.
- **MRR**: reciprocal rank of the first relevant result for each query; this project reports per-query reciprocal rank and its mean (not a separately bootstrapped population estimate).
- **nDCG@k**: discounted gain for relevant results near the top of the list.

## Answer and evidence checks

- **Exact match** normalizes case and punctuation but remains strict.
- **Token F1** measures lexical overlap, not semantic equivalence.
- **Evidence overlap** is a transparent non-stopword overlap proxy, not entailment or factual verification.
- **Citation precision** compares cited IDs to the human-labeled relevant document IDs. Relevance is not always equivalent to direct support, so labels need expert review.

The bundled mock answer adapter returns the reference answer when any labeled relevant document is retrieved and abstains otherwise. This isolates retrieval effects and exercises the pipeline; it is **not** an LLM generation benchmark. Replace it with a real provider adapter and blinded, manually reviewed examples before making model-quality claims.

## Cost and latency

Latency is measured around local retrieval with `perf_counter` and is noisy. Token counts use whitespace word counts, not a model tokenizer. Cost defaults to zero unless a per-1,000-token price is explicitly supplied to the Python API. Real provider evaluations should record provider-reported input/output usage, model ID, price snapshot, retries, and request timing.

## Comparisons and CI gates

Compare at least two named configurations on the same split. The CI gate checks a small minimum Recall@3 on the synthetic held-out fixture; treat it as a wiring/regression smoke test, not a production acceptance threshold. For real use, define thresholds before evaluating, increase the labeled dataset, report per-category failures and uncertainty, and never optimize on held-out test results.

## Optional model-based judging

A future judge can rate correctness, groundedness, and citation support, but it must be calibrated against human annotations. Track judge model/version, rubric, prompt, variance, and disagreement. Do not treat judge scores as ground truth.

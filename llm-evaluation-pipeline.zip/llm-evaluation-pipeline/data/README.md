# Evaluation data

- `corpus.json`: seven short synthetic documents, with stable document IDs.
- `examples.jsonl`: six synthetic evaluation cases (three `dev`, three `test`) with reference answers and relevant document IDs.
- Fixture version: `1.0.0` as reported by the evaluation runner.

No private, employer, or scraped personal data is used. This fixture validates the mechanics of the evaluation pipeline only. It is not large or representative enough for general performance claims. When replacing it, document source, license, label provenance, annotation instructions, split creation, and any personal-data review. Keep held-out test cases out of iterative tuning.

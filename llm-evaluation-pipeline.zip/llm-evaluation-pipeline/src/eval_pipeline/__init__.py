"""Reproducible LLM and retrieval evaluation utilities."""
__version__ = "0.1.0"

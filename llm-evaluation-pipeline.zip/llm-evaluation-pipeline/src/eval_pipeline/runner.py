"""Evaluation orchestration and transparent baseline answer adapter."""
from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any
from .metrics import citation_precision, evidence_overlap, exact_match, ndcg_at_k, recall_at_k, reciprocal_rank, token_f1
from .retrieval import LexicalRetriever

STOP = {"the", "a", "an", "is", "are", "was", "were", "and", "or", "of", "to", "in", "for", "with", "on", "by", "it", "this", "that"}

def mock_answer(question: str, reference: str, retrieved: list[dict[str, Any]], relevant_ids: set[str]) -> tuple[str, list[str]]:
    """Deterministic fixture adapter, not a generative model or quality guarantee."""
    cited = [doc["id"] for doc in retrieved[:2]]
    if any(doc["id"] in relevant_ids for doc in retrieved):
        return reference, cited
    return "I do not have enough evidence to answer that question.", cited

def evaluate(dataset: list[dict[str, Any]], corpus: list[dict[str, Any]], *, config_name: str, title_boost: float, k: int = 3, cost_per_1k_tokens: float = 0.0) -> dict[str, Any]:
    retriever = LexicalRetriever(corpus, title_boost=title_boost)
    cases = []
    for example in dataset:
        started = time.perf_counter()
        retrieved = retriever.search(example["question"], k=k)
        latency_ms = (time.perf_counter() - started) * 1000
        relevant = set(example["relevant_doc_ids"])
        answer, cited_ids = mock_answer(example["question"], example["reference_answer"], retrieved, relevant)
        evidence = " ".join(doc["text"] for doc in retrieved)
        supported = [doc_id for doc_id in relevant if doc_id in {doc["id"] for doc in retrieved}]
        # Approximate input/output token counts from whitespace words, clearly labelled estimates.
        estimated_tokens = len(example["question"].split()) + len(answer.split()) + sum(len(doc["text"].split()) for doc in retrieved)
        cases.append({
            "id": example["id"], "split": example["split"], "question": example["question"],
            "retrieved_doc_ids": [doc["id"] for doc in retrieved], "relevant_doc_ids": sorted(relevant),
            "answer": answer, "reference_answer": example["reference_answer"], "cited_doc_ids": cited_ids,
            "recall_at_k": recall_at_k([doc["id"] for doc in retrieved], relevant, k),
            "reciprocal_rank": reciprocal_rank([doc["id"] for doc in retrieved], relevant),
            "ndcg_at_k": ndcg_at_k([doc["id"] for doc in retrieved], relevant, k),
            "exact_match": exact_match(answer, example["reference_answer"]),
            "token_f1": token_f1(answer, example["reference_answer"]),
            "evidence_overlap": evidence_overlap(answer, evidence),
            "citation_precision": citation_precision(cited_ids, supported),
            "latency_ms": round(latency_ms, 4), "estimated_tokens": estimated_tokens,
            "estimated_cost": round(estimated_tokens / 1000 * cost_per_1k_tokens, 8),
            "notes": "Heuristic metrics and mock answer adapter; not an LLM judge."
        })
    metric_names = ["recall_at_k", "reciprocal_rank", "ndcg_at_k", "exact_match", "token_f1", "evidence_overlap", "citation_precision", "latency_ms", "estimated_tokens", "estimated_cost"]
    means = {name: round(sum(case[name] for case in cases) / len(cases), 6) for name in metric_names}
    return {"schema_version": "1.0", "dataset_version": "1.0.0", "config": {"name": config_name, "title_boost": title_boost, "k": k}, "example_count": len(cases), "metrics": means, "cases": cases}

def compare_reports(reports: list[dict[str, Any]]) -> dict[str, Any]:
    if len(reports) < 2:
        raise ValueError("Comparison requires at least two configuration reports")
    names = [r["config"]["name"] for r in reports]
    if len(names) != len(set(names)):
        raise ValueError("Configuration names must be unique")
    return {"schema_version": "1.0", "comparison": [{"config": r["config"]["name"], "example_count": r["example_count"], "metrics": r["metrics"]} for r in reports], "metric_notes": {"recall_at_k": "Higher is better", "reciprocal_rank": "Higher is better", "ndcg_at_k": "Higher is better", "exact_match": "Higher is better; strict normalized string match", "token_f1": "Higher is better; lexical overlap only", "evidence_overlap": "Higher is better; lexical proxy, not entailment", "citation_precision": "Higher is better; judged against labeled supporting document IDs", "latency_ms": "Lower is better; local measurement is noisy", "estimated_tokens": "Approximate word-count proxy, not provider tokenization", "estimated_cost": "Estimate using configured price; zero by default"}}

def write_report(report: dict[str, Any], output: str | Path) -> None:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

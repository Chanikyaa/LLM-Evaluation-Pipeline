"""Versioned JSONL dataset loading and split safety."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any

class DatasetError(ValueError):
    pass

def load_dataset(path: str | Path, split: str | None = None) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")
    rows = []
    seen = set()
    with path.open(encoding="utf-8") as stream:
        for line_no, line in enumerate(stream, start=1):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise DatasetError(f"Invalid JSON at {path}:{line_no}: {exc.msg}") from exc
            required = {"id", "split", "question", "reference_answer", "relevant_doc_ids"}
            missing = required - row.keys()
            if missing:
                raise DatasetError(f"Missing fields at {path}:{line_no}: {sorted(missing)}")
            if row["id"] in seen:
                raise DatasetError(f"Duplicate example id: {row['id']}")
            seen.add(row["id"])
            if row["split"] not in {"dev", "test"}:
                raise DatasetError(f"Unsupported split {row['split']!r}; expected dev or test")
            rows.append(row)
    if split:
        if split not in {"dev", "test"}:
            raise DatasetError("split must be 'dev' or 'test'")
        rows = [row for row in rows if row["split"] == split]
    if not rows:
        raise DatasetError(f"No examples found for split={split!r}")
    return rows

def load_corpus(path: str | Path) -> list[dict[str, Any]]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, list) or any(not all(k in doc for k in ("id", "title", "text")) for doc in data):
        raise DatasetError("Corpus must be a JSON list of documents with id, title, and text")
    ids = [doc["id"] for doc in data]
    if len(ids) != len(set(ids)):
        raise DatasetError("Corpus document IDs must be unique")
    return data

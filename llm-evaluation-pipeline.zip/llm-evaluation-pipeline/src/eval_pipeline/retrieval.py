"""Small transparent lexical retriever used for deterministic baseline comparisons."""
from __future__ import annotations
import math
from collections import Counter
from typing import Any
from .metrics import tokenize

class LexicalRetriever:
    def __init__(self, documents: list[dict[str, Any]], *, title_boost: float = 0.0):
        self.documents = documents
        self.title_boost = title_boost
        self._prepared = []
        for doc in documents:
            body = tokenize(doc.get("text", ""))
            title = tokenize(doc.get("title", ""))
            self._prepared.append((doc, Counter(body), Counter(title), len(body)))
        self.avg_len = sum(row[3] for row in self._prepared) / max(1, len(self._prepared))
        df = Counter()
        for _, counts, title_counts, _ in self._prepared:
            df.update(set(counts) | set(title_counts))
        self.df = df
        self.n = max(1, len(documents))

    def search(self, query: str, k: int = 3) -> list[dict[str, Any]]:
        q_terms = tokenize(query)
        scored = []
        for doc, counts, title_counts, length in self._prepared:
            score = 0.0
            for term in q_terms:
                if term not in counts and term not in title_counts:
                    continue
                idf = math.log(1 + (self.n - self.df[term] + 0.5) / (self.df[term] + 0.5))
                tf = counts[term]
                denom = tf + 1.2 * (0.25 + 0.75 * length / max(1.0, self.avg_len))
                score += idf * (tf * 2.2 / denom if tf else 0.0)
                if title_counts[term]:
                    score += self.title_boost * idf * (1 + math.log(title_counts[term]))
            scored.append((score, doc.get("id", ""), doc))
        scored.sort(key=lambda item: (-item[0], item[1]))
        return [dict(item[2], _score=round(item[0], 6)) for item in scored[:max(0, k)]]

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from .dataset import load_corpus, load_dataset
from .runner import compare_reports, evaluate, write_report

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
ROOT = Path.cwd() if (Path.cwd() / "data" / "examples.jsonl").exists() else PACKAGE_ROOT

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run deterministic LLM/RAG evaluation experiments")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run", help="evaluate one configuration")
    run.add_argument("--split", choices=["dev", "test"], default="dev")
    run.add_argument("--config", choices=["lexical", "title-boost"], default="lexical")
    run.add_argument("--k", type=int, default=3)
    run.add_argument("--output", default="reports/run.json")
    compare = sub.add_parser("compare", help="compare two configurations on a split")
    compare.add_argument("--split", choices=["dev", "test"], default="dev")
    compare.add_argument("--k", type=int, default=3)
    compare.add_argument("--output", default="reports/comparison.json")
    return parser

def main() -> None:
    args = build_parser().parse_args()
    if args.k < 1:
        raise SystemExit("--k must be at least 1")
    data_path = ROOT / "data" / "examples.jsonl"
    corpus_path = ROOT / "data" / "corpus.json"
    try:
        dataset, corpus = load_dataset(data_path, args.split), load_corpus(corpus_path)
        configs = {"lexical": ("lexical", 0.0), "title-boost": ("title-boost", 1.5)}
        if args.command == "run":
            name, boost = configs[args.config]
            report = evaluate(dataset, corpus, config_name=name, title_boost=boost, k=args.k)
        else:
            reports = [evaluate(dataset, corpus, config_name=name, title_boost=boost, k=args.k) for name, boost in configs.values()]
            report = compare_reports(reports)
        write_report(report, args.output)
        print(json.dumps({"output": args.output, "result": report}, indent=2))
    except (ValueError, OSError) as exc:
        print(f"evaluation failed: {exc}", file=sys.stderr)
        raise SystemExit(2) from exc

if __name__ == "__main__":
    main()

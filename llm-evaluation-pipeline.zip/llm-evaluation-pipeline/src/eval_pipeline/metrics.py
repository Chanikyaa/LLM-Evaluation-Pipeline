"""Deterministic evaluation metrics; scores are heuristics, not semantic truth."""
from __future__ import annotations
import math
import re
from collections import Counter
from typing import Iterable, Sequence

_TOKEN_RE = re.compile(r"[a-z0-9]+(?:'[a-z0-9]+)?", re.I)

def tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())

def recall_at_k(retrieved: Sequence[str], relevant: Iterable[str], k: int) -> float:
    rel = set(relevant)
    return len(set(retrieved[:k]) & rel) / len(rel) if rel else 0.0

def reciprocal_rank(retrieved: Sequence[str], relevant: Iterable[str]) -> float:
    rel = set(relevant)
    for rank, doc_id in enumerate(retrieved, start=1):
        if doc_id in rel:
            return 1.0 / rank
    return 0.0

def ndcg_at_k(retrieved: Sequence[str], relevant: Iterable[str], k: int) -> float:
    rel = set(relevant)
    dcg = sum((1.0 / math.log2(rank + 1)) for rank, doc_id in enumerate(retrieved[:k], start=1) if doc_id in rel)
    ideal_count = min(len(rel), k)
    ideal = sum(1.0 / math.log2(rank + 1) for rank in range(1, ideal_count + 1))
    return dcg / ideal if ideal else 0.0

def exact_match(prediction: str, reference: str) -> float:
    normalize = lambda s: " ".join(tokenize(s))
    return float(normalize(prediction) == normalize(reference))

def token_f1(prediction: str, reference: str) -> float:
    pred, ref = Counter(tokenize(prediction)), Counter(tokenize(reference))
    if not pred or not ref:
        return float(not pred and not ref)
    overlap = sum((pred & ref).values())
    if not overlap:
        return 0.0
    precision, recall = overlap / sum(pred.values()), overlap / sum(ref.values())
    return 2 * precision * recall / (precision + recall)

def evidence_overlap(answer: str, evidence: str) -> float:
    """Fraction of non-stopword answer tokens found in evidence (weak support proxy)."""
    stop = {"the", "a", "an", "is", "are", "was", "were", "and", "or", "of", "to", "in", "for", "with", "on", "by", "it", "this", "that"}
    answer_tokens = {t for t in tokenize(answer) if t not in stop}
    if not answer_tokens:
        return 1.0 if not answer.strip() else 0.0
    evidence_tokens = set(tokenize(evidence))
    return len(answer_tokens & evidence_tokens) / len(answer_tokens)

def citation_precision(cited_ids: Sequence[str], supporting_ids: Iterable[str]) -> float:
    cited = list(cited_ids)
    if not cited:
        return 0.0
    support = set(supporting_ids)
    return sum(doc_id in support for doc_id in cited) / len(cited)

from pathlib import Path
import pytest
from eval_pipeline.dataset import DatasetError, load_corpus, load_dataset

ROOT = Path(__file__).resolve().parents[1]

def test_dataset_splits_are_disjoint_and_versioned_fixture_loads():
    dev = load_dataset(ROOT / "data/examples.jsonl", "dev")
    test = load_dataset(ROOT / "data/examples.jsonl", "test")
    assert len(dev) == 3 and len(test) == 3
    assert not ({row["id"] for row in dev} & {row["id"] for row in test})

def test_duplicate_ids_are_rejected(tmp_path):
    p = tmp_path / "data.jsonl"
    row = '{"id":"x","split":"dev","question":"q","reference_answer":"a","relevant_doc_ids":[]}\n'
    p.write_text(row + row, encoding="utf-8")
    with pytest.raises(DatasetError, match="Duplicate"):
        load_dataset(p)

def test_corpus_loads_with_unique_ids():
    assert len(load_corpus(ROOT / "data/corpus.json")) >= 5

from eval_pipeline.metrics import citation_precision, exact_match, ndcg_at_k, recall_at_k, reciprocal_rank, token_f1

def test_retrieval_metrics_known_values():
    retrieved, relevant = ["a", "x", "b"], {"a", "b"}
    assert recall_at_k(retrieved, relevant, 2) == 0.5
    assert reciprocal_rank(retrieved, relevant) == 1.0
    assert 0.7 < ndcg_at_k(retrieved, relevant, 3) < 1.0

def test_answer_metrics_normalize_and_compare_tokens():
    assert exact_match("Hybrid Search!", "hybrid search") == 1.0
    assert token_f1("cats chase mice", "cats chase birds") > 0.4
    assert token_f1("unrelated", "different") == 0.0

def test_citation_precision_handles_empty_and_unsupported():
    assert citation_precision([], {"a"}) == 0.0
    assert citation_precision(["a", "b"], {"a"}) == 0.5

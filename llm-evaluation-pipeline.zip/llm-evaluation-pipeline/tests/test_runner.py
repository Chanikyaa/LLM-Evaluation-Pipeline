from pathlib import Path
from eval_pipeline.dataset import load_corpus, load_dataset
from eval_pipeline.runner import compare_reports, evaluate, write_report
import json

ROOT = Path(__file__).resolve().parents[1]

def test_evaluation_is_reproducible_except_latency():
    dataset = load_dataset(ROOT / "data/examples.jsonl", "test")
    corpus = load_corpus(ROOT / "data/corpus.json")
    a = evaluate(dataset, corpus, config_name="lexical", title_boost=0, k=3)
    b = evaluate(dataset, corpus, config_name="lexical", title_boost=0, k=3)
    for report in (a, b):
        report["metrics"].pop("latency_ms")
        for case in report["cases"]:
            case.pop("latency_ms")
    assert a == b

def test_comparison_requires_two_unique_configurations():
    dataset = load_dataset(ROOT / "data/examples.jsonl", "dev")
    corpus = load_corpus(ROOT / "data/corpus.json")
    one = evaluate(dataset, corpus, config_name="a", title_boost=0)
    two = evaluate(dataset, corpus, config_name="b", title_boost=1.5)
    assert len(compare_reports([one, two])["comparison"]) == 2

def test_report_written_as_valid_json(tmp_path):
    dataset = load_dataset(ROOT / "data/examples.jsonl", "dev")
    corpus = load_corpus(ROOT / "data/corpus.json")
    report = evaluate(dataset, corpus, config_name="test", title_boost=0)
    target = tmp_path / "nested/report.json"
    write_report(report, target)
    assert json.loads(target.read_text(encoding="utf-8"))["example_count"] == 3
